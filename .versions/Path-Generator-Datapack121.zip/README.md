# Path-Generator-Datapack
Automatically generate path block trails over frequently travelled areas
